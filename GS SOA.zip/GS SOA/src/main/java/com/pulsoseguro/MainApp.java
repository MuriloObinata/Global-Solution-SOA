package com.pulsoseguro;

import com.pulsoseguro.controller.PulsoSeguroController;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("🚀 Pulso Seguro Iniciado!");
        PulsoSeguroController controller = new PulsoSeguroController();
        
        controller.iniciarVarredura("Ponto A - Setor 1");
        controller.iniciarVarredura("Ponto B - Escombros Norte");
    }
}