package com.pulsoseguro.service;

import com.pulsoseguro.model.Deteccao;

public interface DetectorService {
    boolean verificarSinaisVitais();
    Deteccao gerarAlerta(String localizacao);
    void ativarSinaisLocais();
}