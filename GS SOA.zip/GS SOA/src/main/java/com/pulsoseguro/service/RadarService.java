package com.pulsoseguro.service;

import com.pulsoseguro.model.Deteccao;

public class RadarService implements DetectorService {
    @Override
    public boolean verificarSinaisVitais() {
        // Simulação - sempre detecta movimento
        System.out.println("🔍 Sinais vitais detectados!");
        return true;
    }

    @Override
    public Deteccao gerarAlerta(String localizacao) {
        Deteccao alerta = new Deteccao();
        alerta.setIdDispositivo("PS-001");
        alerta.setLocalizacao(localizacao);
        alerta.setTimestamp(java.time.Instant.now().toString());
        return alerta;
    }

    @Override
    public void ativarSinaisLocais() {
        System.out.println("🚨 LED e Buzzer ativados!");
    }
}