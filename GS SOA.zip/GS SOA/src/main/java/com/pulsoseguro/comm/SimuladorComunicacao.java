package com.pulsoseguro.comm;

import com.pulsoseguro.model.Deteccao;

public class SimuladorComunicacao {
    public void enviarAlerta(Deteccao alerta) {
        System.out.println("\n📢 [SIMULAÇÃO] Alerta enviado para dispositivos próximos:");
        System.out.println("   📍 Local: " + alerta.getLocalizacao());
        System.out.println("   🆔 Dispositivo: " + alerta.getIdDispositivo());
        System.out.println("   ⏰ Timestamp: " + alerta.getTimestamp());
        
        // Simula delay de rede
        try { Thread.sleep(1500); } 
        catch (InterruptedException e) {}
        
        System.out.println("✅ Alerta recebido com sucesso (simulado)");
    }
}