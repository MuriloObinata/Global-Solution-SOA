package com.pulsoseguro.controller;

import com.pulsoseguro.service.*;
import com.pulsoseguro.comm.*;
import com.pulsoseguro.model.Deteccao;

public class PulsoSeguroController {
    private final DetectorService detectorService;
    private final SimuladorComunicacao comunicacaoService;

    public PulsoSeguroController() {
        this.detectorService = new RadarService();
        this.comunicacaoService = new SimuladorComunicacao();
    }

    public void iniciarVarredura(String localizacao) {
        System.out.println("\n=================================");
        System.out.println("🔎 Varrendo: " + localizacao);
        
        if(detectorService.verificarSinaisVitais()) {
            Deteccao alerta = detectorService.gerarAlerta(localizacao);
            detectorService.ativarSinaisLocais();
            comunicacaoService.enviarAlerta(alerta);
        }
    }
}